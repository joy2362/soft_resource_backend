<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                    <a class="text-muted" href="{{route('home')}}"><strong>{{$app_name}}</strong></a> &copy;
                </p>
            </div>
        </div>
    </div>
</footer>